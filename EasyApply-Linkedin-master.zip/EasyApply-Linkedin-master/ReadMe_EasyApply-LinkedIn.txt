EasyApply-LinkedIn
Easily automate your job application process on LinkedIn with this tool!

Getting Started
Follow these instructions to set up the project on your local machine for development and testing purposes.

Prerequisites
Install Selenium
Use pip to install the Selenium package:
pip install selenium


Download and Set Up WebDriver
Selenium requires a WebDriver to interface with your chosen browser. Download the appropriate driver for your browser and add its path to the config.json file.

(https://sites.google.com/a/chromium.org/chromedriver/downloads). You can also download [Edge](https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/), [Firefox](https://github.com/mozilla/geckodriver/releases) or [Safari](https://webkit.org/blog/6900/webdriver-support-in-safari-10/). Depends on your preferred browser.


Usage
Fork and Clone/Download the Repository
Download or clone the repository to your local machine.

Update Configuration File
Modify the config.json file with the following details:

Your LinkedIn email.
Your LinkedIn password.
Keywords for job titles you are interested in (e.g., Machine Learning Engineer, Data Scientist).
The location where you're seeking positions.
The path to your downloaded WebDriver.

Run the Application
Execute the script by running:
python main.py
